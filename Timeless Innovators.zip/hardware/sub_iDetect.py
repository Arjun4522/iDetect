import paho.mqtt.client as mqtt

broker_address = "192.168.0.104"

topic = "Sensor_Data"

def on_message(client, userdata, message):
    print(f"Received message '{message.payload.decode()}' on topic '{message.topic}'")

client = mqtt.Client()
client.on_message = on_message

client.connect(broker_address)
client.subscribe(topic)
client.loop_forever()