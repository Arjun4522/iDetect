import RPi.GPIO as GPIO
import time
import paho.mqtt.client as mqtt
import serial

GPIO.setmode(GPIO.BCM)

broker = "192.168.0.104"
topic = "Sensor_Data"
client = mqtt.Client()
client.connect(broker)
ser = serial.Serial('/dev/ttyUSB0', 9600)

flamepin = 2
shockpin = 4
linepin = 18

GPIO.setup(flamepin, GPIO.IN)
GPIO.setup(shockpin, GPIO.IN)
GPIO.setup(linepin, GPIO.IN)
try:
    while True:
        message = ""
        flame = GPIO.input(flamepin)
        shock = GPIO.input(shockpin)
        line = GPIO.input(linepin)

        if (flame == GPIO.HIGH):
            message = "Flame Detected"
        else:
            message = "No Flame Detected"
        client.publish(topic, message)

        if (shock == GPIO.HIGH):
            message = "Shock Detected"
        else:
            message = "No Shock Detected"
        client.publish(topic, message)

        if (line == GPIO.HIGH):
            message = "Object Detected"
        else:
            message = "No Object Detected"
        client.publish(topic, message)

        data = ser.readline().decode('utf-8').strip()
        client.publish(topic, data)

        data = ser.readline().decode('utf-8').strip()
        client.publish(topic, data)

        data = ser.readline().decode('utf-8').strip()
        client.publish(topic, data)

except KeyboardInterrupt:
    GPIO.cleanup()
    print("Publishing Stopped")